A Pen created at CodePen.io. You can find this one at https://codepen.io/frytyler/pen/juGfk.

 HTML5 video skin. 

Found a great tutorial that walks you through how to skin an html5 video. Works great and looks great! Try it out

Tutorial: http://www.inwebson.com/html5/custom-html5-video-controls-with-jquery/

Original design here http://dribbble.com/shots/866381-Mini-Player